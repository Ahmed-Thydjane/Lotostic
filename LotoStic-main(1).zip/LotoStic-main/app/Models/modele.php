<?php namespace App\Models;

use CodeIgniter\Model;

class Modele extends Model
{
    protected $db;
    public $idMax;
    public $builder;


    public function __construct()
    {
        $this->$db = db_connect('default');
        $this->$builder = $this->$db->table('tirages');
        $this->$idMax = $this->maxId();
        
    }
    
    public function getIdMax(){
        
        return $this->$idMax;
    }

    public function maxId()
    {   
        
        $this->$builder->selectCount('id');
        $this->$builder->limit(1);
        
        $query = $this->$builder->get();
        $result = $query->getResult('array');
        
        
        if(is_array($result) && count($result) > 0) {
            $num_res = $result[0]['id'];
            
        }
        
        if( $num_res == 0 ) return 0 ;
        else
        {
            $this->$builder->selectMax('anne_numero');
            $this->$builder->limit(1);
            $query = $this->$builder->get();
            $result = $query->getResult('array');

            $max = $result[0]['anne_numero'];
                
            return $max ;  
        }
    }

    public function injecterUnTirage( array $tirage )
    {
        $data = [
            'anne_numero' => $tirage[0],
            'boule1' => $tirage[1],
            'boule2' => $tirage[2],
            'boule3' => $tirage[3],
            'boule4' => $tirage[4],
            'boule5' => $tirage[5],
            'num_chance' => $tirage[6]
        ];
        $this->$db = db_connect('default');
        $this->$builder = $this->$db->table('tirages');
        $this->$builder->insert($data);
    }

    public function tousLesTirages()
    {
        $this->$db = db_connect('default');
        $this->$builder = $this->$db->table('tirages');
        $this->$builder->select('boule1, boule2,boule3,boule4,boule5,num_chance');
        $query = $this->$builder->get();
        $result = $query->getResult('array');
        
        return $result;
    }
}

?>