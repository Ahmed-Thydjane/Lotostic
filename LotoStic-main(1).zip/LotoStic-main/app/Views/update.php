<!DOCTYPE html>
<html lang="en">
<?php include("head.php"); ?>

    <body id="page-top">
    <?php include("header.php"); ?>
        <section class="page-section">
            <div class="container">
                <!-- About Section Heading-->
                <div class="text-center">
                    <h2 class="page-section">   MISE A JOUR DE LA BASE DE DONNEES</h2>
                    <p>Les données de tirages seront importées depuis le site officiel de la FDJ</p>
                </div>
                
                <div>
                <button class="btn btn-secondary btn-icon-split" id="btn_proba" type="button" onclick="exec_Maj()" style="margin-top:20px;" >
                    <span class="icon text-white-50">
                        <i class="fas fa-arrow-right"></i>
                    </span>
                    <span class="text">Mettre à jour les données de tirage</span>
                </button>
                <p id="message"></p>
                </div>
        </section>


        <script>
            function exec_Maj() {

                var paragraph = document.getElementById("message");
                var text = document.createTextNode("Mise à jour en cours ...");
                paragraph.appendChild(text);

                setTimeout(function(){
                    $.get(
                    '/execute_update',  
                    setMessageResult,          
                    'text'                    
                );
                }, 2000);
                /*
                
                location.href = "/execute_update";*/
            }
            function setMessageResult(message){
                
                document.getElementById('message').innerText = message;
            }
        </script>
        <?php include("foot.php"); ?>
    </body>
</html>

