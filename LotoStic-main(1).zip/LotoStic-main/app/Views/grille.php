<!DOCTYPE html>
<html lang="en">
<?php include("head.php"); ?> 

    <body id="page-top">
        <?php include("header.php"); ?>
            <section class="page-section" id="grille_strateqique">
            <div class="container">
                <!-- About Section Heading     **class="page-section bg-primary text-white mb-0"**-->
                <div class="text-center">
                    <h2 class="page-section text-secondary d-inline-block mb-0">GRILLE STRATEGIQUE</h2>
                </div>
              
                <!-- About Section Content-->
                <div>
                  
                <form id="form_grille" action="grilleSR" method="post" class="container tests" onsubmit="return checkSelected()">
                    <table style="display:inline">
                        <legend>Cochez 6 à 10 numeros de boule</legend>
                        <hr/>
                        <tr>
                            <td>
                                    <?php
                                    $tab;
                                    $i;
                                    $j;
                                    $cpt=1;
                                    ?>
                                    <table border="0" cellspacing="0" cellpadding="0">
                                        <?php for($i=0;$i<7;$i++) : ?>
                                        <tr>
                                            <?php for($j=0;$j<7;$j++) : ?>
                                                <td width="15" align="center"><?= $cpt ?></td>
                                                <td width="15" align="center"><input class="case" type="checkbox" id="<?= $cpt ?>" name="boule[]"  value="<?= $cpt ?>"></td>
                                                <td width="10" align="center">&nbsp;</td>
                                                <?php $cpt++; ?>
                                            <?php endfor; ?>
                                        </tr>
                                        <?php endfor; ?>
                                    </table>
                                
                            </td>
                            <td width="50"></td>
                            <td width="15">
                                <div id="objectif">
                                <label for="objectif">Combien de Numéro chance souhaitez vous avoir ?</label>
                                        <select name="obj" id="obj">
                                            <option value="1" selected>1 BON NUMERO</option>
                                            <option value="2">2 BONS NUMEROS</option>
                                            <option value="3">3 BONS NUMEROS</option>
                                            <option value="4">4 BONS NUMEROS</option>
                                            <option value="5">5 BONS NUMEROS</option>
                                        </select>
                                    </div>         
                            </td>
                            <td width="100"></td>
                            <td>
                                <div id="tab-grille" class="test" style="display:inline-bloc;">
                                    <?php if(isset($data)){ ?>
                                        <?php foreach ($data as $key => $tab) { 
                                        echo "<table class='table-grille'>";
                                        echo "<tr>";
                                        foreach ($tab as $k => $value) { 
                                            echo "<td style='width=20px;' class='td-grille'>$value</td>"; 
                                        }
                                        echo "</tr>";
                                        }
                                        echo "</table>";
                                    }?>
                                </div>
                            </td>
                        <tr>
                    </table>
                    
                    <hr/>
                    
                    <button id="btn_grille" type="submit" HEIGHT="100px" WIDTH="20px" class="nav-item mx-0 mx-lg-1" class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" >
                        Générer des grilles stratégiques
                    </button>
                </form>
                </div>
            </div>
        </section>

        <script>
            
            function checkSelected(){

                var numberOfChecked = $('input:checkbox:checked').length;

                if(numberOfChecked < 6 || numberOfChecked > 10){
                    alert("Cochez entre 6 et 10 numeros");
                    return false;
                }else{
                    return true;
                }
                
            }
        </script>
        <?php include("foot.php"); ?>
        
    </body>
</html>
       
