<!DOCTYPE html>
<html lang="en">
<?php include("head.php"); ?>


    <body id="page-top">
    <?php include("header.php"); ?>

    
        <header  class="masthead bg-primary text-white text-center">
            <div  class="container d-flex align-items-center flex-column" background="loto.png">
                <!-- Masthead Avatar Image--><img class="masthead-avatar mb-5" src="../assets/asset/img/avataaars.svg" alt="">
                <!-- Masthead Heading-->
                <h1 class="masthead-heading mb-0">BIENVENU SUR LOTOSTIC</h1>
                <!-- Icon Divider-->
                <div class="divider-custom divider-light">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- Masthead Subheading-->
                <p class="pre-wrap masthead-subheading font-weight-light mb-0">Maximiser vos Chances de gagner au Loto avec nos statistiques</p>
            </div>
        </header>

        
        
        

        

        


        
        <?php include("foot.php"); ?>
    </body>
</html>