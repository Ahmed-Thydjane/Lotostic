<!DOCTYPE html>
<html lang="en">
  
<?php include("head.php"); ?>


    <body id="page-top">
    <?php include("header.php"); ?>

        <section class="page-section" id="boules_freq">
            <div class="container">
                <!-- Portfolio Section Heading-->
                <div class="text-center">
                    <h2 class="page-section text-secondary mb-0 d-inline-block">FREQUENCES DES BOULES</h2>
                </div>
                <!-- Icon Divider-->
                <!-- Les plus tirés -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary" style="color : #009688;">Les plus tirés</h6>
                    </div>
                    <div class="card-body">
                        <div class="chart-bar">
                            <canvas id="myBarChart"></canvas>
                        </div>
                        
                        <hr>
                        <p style="text-align : center;">Les numéros normaux les plus tirés</p>
                    </div>
                </div>
                <!-- les moins tirés -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold" style="color : #494949;">Les moins tirés</h6>
                    </div>
                    <div class="card-body">
                        <div class="chart-bar">
                            <canvas id="myBarChart2"></canvas>
                        </div>
                        
                        <hr>
                        <p style="text-align : center;">Les numéros normaux les moins tirés</p>
                    </div>
                </div>
            </div>
            </div>
        </section>
        
         <?php include("foot.php"); ?>
    </body>
</html>

   </body>