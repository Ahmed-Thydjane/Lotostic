<!DOCTYPE html>
<html lang="en">
<?php include("head.php"); ?>
    <body id="page-top">
    <?php include("header.php"); ?>
    
        
            <section class="page-section" id="estimation_gain">
            <div class="container">
                <!-- About Section Heading-->
                <div class="text-center">
                    <h2 class="page-section d-inline-block text-Black">ESTIMATION DE GAIN</h2>
                </div>
                <!-- Icon Divider-->
                <div class="row justify-content-center divider-custom divider">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- About Section Content-->
                <div>
                   <table>
                    <tr>
                        <td>
                            <h3>ESTIMATION 1 </h3>
                            </td> 
                            <td style="padding-left: 60px" >
                                <h3>ESTIMATION 2 </h3>
                            </td>
                        </tr>
                        <tr>
                            <td >
                                <h3>Obtenez votre Chance de Gain en fonction de votre mise</h3>
                                <p>Saisissez la somme total avec laquelle vous comptez jouer</p>
                                <form action="estimation1" method="post">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input class="form-control form-control-user" type="number" id="mise" name="mise" step=".01" min="0.00">
                                    </div>
                                    </br>
                                    
                                    </br>
                                    <button class="btn btn-secondary btn-icon-split" id="btn_chance" type="submit">
                                        <span class="icon text-white-50">
                                            <i class="fas fa-arrow-right"></i>
                                        </span>
                                        <span class="text">VERIFIER MES CHANCES DE GAGNER</span>
                                    </button>
                                </form>
                            </td>
                            <td style="padding-left: 60px" >
                                <h3>Obtenez le montant total à jouer pour la chance souhaité</h3>
                                <p>Saisissez la probabilité avec laquelle vous souhaitez gagner</p>
                                <form action="estimation2" method="post">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input class="form-control form-control-user" type="number" step=".01" min="0.0" max="100.00" id="probabilite" name="probabilite">
                                    </div>
                                    </br>
                                    </br>
                                    <button class="btn btn-secondary btn-icon-split" id="btn_proba" type="submit" >
                                        <span class="icon text-white-50">
                                            <i class="fas fa-arrow-right"></i>
                                        </span>
                                        <span class="text">OBTENIR LE MONTANT A JOUER</span>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="row justify-content-center" style="margin-top : 20px;">
                    <?php if(isset($type) && isset($chance) && ($type=="estimation1")) { ?>
                        
                            <!-- Chances Card -->
                            <div class="col-xl-3 col-md-6 mb-4">
                                <div class="card border-left-info shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Chances
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-auto">
                                                        <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?php echo $chance." %";?></div>
                                                    </div>
                                                    <div class="col">
                                                        <div class="progress progress-sm mr-2">
                                                            <div class="progress-bar bg-info" role="progressbar" style="width: <?php echo $chance;?>%" aria-valuenow="<?php echo $chance." %";?>" aria-valuemin="0" aria-valuemax="100"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                    <?php } ?>
                    <?php if(isset($type) && isset($couts) && ($type=="estimation2")) { ?>
                        <!-- Couts Card -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Coût</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $couts." €"; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                    <?php if(isset($nbTicket)) { ?>
                        <!-- Tickets Card -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Nombre de tickets</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $nbTicket; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </section>



        <?php include("foot.php"); ?>
    </body>
</html>

