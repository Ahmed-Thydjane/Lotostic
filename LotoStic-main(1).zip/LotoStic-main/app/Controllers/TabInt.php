<?php

class TabInt
{
	private $tab ;
	

	// ---------------------------------- MÉTHODES ÉLÉMENTAIRES ----------------------------------


	// On suppose que tab0 est un tableau d'entier
	public function __construct( array $tab0 = array() ) 
	{
		$this->tab = $tab0 ;
	}

	public function get( int $pos ) : int 
	{
		return $this->tab[$pos] ;
	}

	public function set( int $pos, int $val )
	{
		$this->tab[$pos] = $val ;
	}

	public function push( int $x )
	{
		array_push( $this->tab, $x );
	}

	public function copie() : TabInt
	{
		return new TabInt( $this->tab );
	}

	public function __toString() : string
	{
		$res = "( " ;
		foreach( $this->tab as $x ) $res = $res . "$x " ;
		$res = $res . ")" ;
		return $res ;
	}


	// ---------------------------------- MÉTHODES DE VÉRIFICATIONS ----------------------------------


	// Retourne si l'objet courant est un ensemble (au sens mathématique)
	//
	public function estUnEnsemble() : bool
	{
		$n = count( $this->tab );

		for( $i=0 ; $i<$n-1 ; $i++ )
		{
			for( $j=$i+1 ; $j<$n ; $j++ )
			{
				if( $this->tab[$i] == $this->tab[$j] ) return false ;
			}
		}

		return true ;
	}


	// On suppose que X1 et X2 sont des ensembles
	// Retourne si les ensembles X1 et X2 sont égaux ( au sens ensemble mathématique )
	//
	public static function ensemblesEgaux( TabInt $X1, TabInt $X2 ) : bool
	{
		if( count($X1->tab) != count($X2->tab) ) return false ;

		foreach( $X1->tab as $x1 )
		{
			$trouve = false ;
			foreach( $X2->tab as $x2 )
			{
				if( $x1 == $x2 ) 
				{
					$trouve = true ;
					break ;
				}
			}
			if( !$trouve ) return false ;
		}

		return true ;
	}


	// Retourne si x0 appartient à l'objet courant
	//
	public function appartient_int( int $x0 ) : bool
	{
		return in_array( $x0, $this->tab );
	}


	// On suppose que XX est un array de TabInt
	// Retourne si l'objet courant appartient à XX
	//
	public function appartient_ens( array $XX ) : bool
	{
		foreach( $XX as $X )
		{
			if( TabInt::ensemblesEgaux($this,$X) ) return true ;
		}
		return false ;
	}



	// Retourne si l'objet courant est un sous ensemble de X0
	//
	public function estUnSousEnsemble( TabInt $X0 ) : bool
	{
		foreach( $this->tab as $x )
		{
			if( ! $X0->appartient_int($x) ) return false ;
		}
		return true ;
	}


	//  ---------------------------------- AUTRES MÉTHODES ----------------------------------


	// On suppose que XX est un tableau de TabInt 
	// Retourne les entiers présents dans $XX
	//
	public static function entiersPresents( array $XX ) : array
	{
		$res = array();
	
		foreach( $XX as $tabInt )
		{
			foreach( $tabInt->tab as $x )
			{
				if( !in_array($x,$res) ) array_push( $res, $x );
			}
		}
	
		return $res ;
	}
	

	// Retourne le nombre d'élément en commun entre X1 et X2
	//
	public static function nbElementEnCommun( TabInt $tabInt1, TabInt $tabInt2 ) : int
	{
		$res = 0 ;

		foreach( $tabInt1->tab as $x1 )
		{
			foreach( $tabInt2->tab as $x2 )
			{
				if( $x1 == $x2 ) {
					$res++ ;
					break ;
				}
			}
		}

		return $res ;
	}
	
	
	public static function arrayTabInt_to_arrayArray( $arrayTabInt )
	{
		$res = array();

		foreach( $arrayTabInt as $tabInt )
		{
			array_push( $res, $tabInt->tab );
		}

		return $res ;
	}
}

?>