<?php namespace App\Controllers;

use App\Models\Modele;

	class Statistiques extends BaseController
	{ 
		public function __construct()
        {
            $this->modele = new modele();
		}

		public function index()
		{
			return view('statistiques');
		}

		public function estimation()
		{
			return view('estimation');
		}
		/*========================================================================================================================
											||
			BOULES LES PLUS/MOINS TIRÉES	||
											||
		====================================*/


		// Retourne un tableau contenant:
		//		+ un tableau qui a pour:
		//				+ clé: les 5 de boules de 1 à 49 les plus tirées
		//				+ valeur: leur fréquence
		//		+ un tableau qui a pour:
		//				+ clé: les 3 boules chances les plus tirées
		//				+ valeur: leur fréquence
		
		//
		function boulesLesPlusTirees()
		{
			$frequences = $this->frequence();

			arsort( $frequences[0] );
			arsort( $frequences[1] );
			$res1 = array_slice( $frequences[0], 0, 5, true );
			$res2 = array_slice( $frequences[1], 0, 3, true );

			//return [ $res1, $res2 ] ;
			
			echo json_encode($res1);
		}


		// Retourne un tableau contenant:
		//		+ un tableau qui a pour:
		//				+ clé: les 5 de boules de 1 à 49 les moins tirées
		//				+ valeur: leur fréquence
		//		+ un tableau qui a pour:
		//				+ clé: les 3 boules chances les moins tirées
		//				+ valeur: leur fréquence
		//
		function boulesLesMoinsTirees()
		{
			$frequences = $this->frequence();

			asort( $frequences[0] );
			asort( $frequences[1] );
			$res1 = array_slice( $frequences[0], 0, 5, true );
			$res2 = array_slice( $frequences[1], 0, 3, true );

			//return [ $res1, $res2 ] ;
			
			echo json_encode($res1);
		}


		// Retourne un tableau contenant:
		//		+ un tableau qui a pour:
		//				+ clé: les boules de 1 à 49
		//				+ valeur: leur fréquence
		//		+ un tableau qui a pour:
		//				+ clé: les boules chances
		//				+ valeur: leur fréquence
		//
		function frequence() : array
		{
			$TsLesTirages = $this->modele->tousLesTirages();
			$frequenceN = array();												// frequence des boules normales
			$frequenceC = array();												// fréquence des numéro chances

			for( $i=1 ; $i<=49 ; $i++ ) $frequenceN[$i] = 0 ;
			for( $i=1 ; $i<=10 ; $i++ ) $frequenceC[$i] = 0 ;

			foreach( $TsLesTirages as $row )
			{		
				
					$boule1 = intval( $row['boule1'] );
					$frequenceN[$boule1] += 1 ;
					$boule2 = intval( $row['boule2'] );
					$frequenceN[$boule2] += 1 ;
					$boule3 = intval( $row['boule3'] );
					$frequenceN[$boule3] += 1 ;
					$boule4 = intval( $row['boule4'] );
					$frequenceN[$boule4] += 1 ;
					$boule5 = intval( $row['boule5'] );
					$frequenceN[$boule5] += 1 ;
					

				$boule = intval( $row['num_chance'] );
				$frequenceC[ $boule ] += 1 ;
			}
			
			
			return [ $frequenceN, $frequenceC ];
		}



		/*========================================================================================================================
																				||
			POURCENTAGE DE CHANCE DE GAGNER GROS LOT EN FONCTION DU BUDGET		||
																				||
		========================================================================*/


		// si $budget est un nombre positif:
		// 		+ retourne un tableau contenant:
		// 			+ le nombre maximum de ticket pouvant être acheté avec ce budget ( en euro )
		// 			+ le pourcentage de gagner le gros lot avec ce nombre de ticket
		//
		// sinon:
		//		+ retourne false
		//
		function budgetToChance( )
		{
			$prix = 2.20 ;
			$nbCombi = 19068840 ;

			$budget = $this->request->getPost('mise');

			if( ! is_numeric($budget) ) return false ;
			if( $budget < 0 ) return false ;

			$nbTicket = floor( $budget / $prix );
			if( $nbTicket > $nbCombi ) $nbTicket = $nbCombi ;
			$chance =  ( $nbTicket / $nbCombi )*100 ;
			
			$data['type'] = "estimation1";
			$data['chance'] = round($chance, 3);
			$data['nbTicket'] = $nbTicket;
			
			return view("estimation", $data);
		}



		/*========================================================================================================================
															||
			COUT EN FONCTION DE CHANCE DE GAGNER GROS LOT	||
															||
		====================================================*/


		// si $chance est un nombre entre 0 et 100:
		//		+  retourne false
		//
		// sinon:
		// 		+ retourne un tableau contenant:
		// 			+ le nombre maximum de ticket pouvant être acheté avec ce budget
		//			+ le coûts d’achats de ces tickets
		//
		function chanceToCouts()
		{
			$prix = 2.20 ;
			$nbCombi = 19068840 ;

			$chance = $this->request->getPost('probabilite');

			if( ! is_numeric($chance) ) return false ;
			if( ($chance > 100) || ($chance < 0) ) return false ;
			
			$nbTicket = floor( ($chance * $nbCombi) / 100 );
			$couts = $nbTicket * $prix ;

			$data['type'] = "estimation2";
			$data['couts'] = $couts;
			$data['nbTicket'] = $nbTicket;
			
			return view("estimation", $data);
		}

	}
?>