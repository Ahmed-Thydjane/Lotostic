<?php namespace App\Controllers;

use App\Models\Modele;
use App\Controllers\TabInt;



class TabInt
{
	private $tab ;
	

	// ---------------------------------- MÉTHODES ÉLÉMENTAIRES ----------------------------------


	// On suppose que tab0 est un tableau d'entier
	public function __construct( array $tab0 = array() ) 
	{
		$this->tab = $tab0 ;
	}

	public function get( int $pos ) : int 
	{
		return $this->tab[$pos] ;
	}

	public function set( int $pos, int $val )
	{
		$this->tab[$pos] = $val ;
	}

	public function push( int $x )
	{
		array_push( $this->tab, $x );
	}

	public function copie() : TabInt
	{
		return new TabInt( $this->tab );
	}

	public function __toString() : string
	{
		$res = "( " ;
		foreach( $this->tab as $x ) $res = $res . "$x " ;
		$res = $res . ")" ;
		return $res ;
	}


	// ---------------------------------- MÉTHODES DE VÉRIFICATIONS ----------------------------------


	// Retourne si l'objet courant est un ensemble (au sens mathématique)
	//
	public function estUnEnsemble() : bool
	{
		$n = count( $this->tab );

		for( $i=0 ; $i<$n-1 ; $i++ )
		{
			for( $j=$i+1 ; $j<$n ; $j++ )
			{
				if( $this->tab[$i] == $this->tab[$j] ) return false ;
			}
		}

		return true ;
	}


	// On suppose que X1 et X2 sont des ensembles
	// Retourne si les ensembles X1 et X2 sont égaux ( au sens ensemble mathématique )
	//
	public static function ensemblesEgaux( TabInt $X1, TabInt $X2 ) : bool
	{
		if( count($X1->tab) != count($X2->tab) ) return false ;

		foreach( $X1->tab as $x1 )
		{
			$trouve = false ;
			foreach( $X2->tab as $x2 )
			{
				if( $x1 == $x2 ) 
				{
					$trouve = true ;
					break ;
				}
			}
			if( !$trouve ) return false ;
		}

		return true ;
	}


	// Retourne si x0 appartient à l'objet courant
	//
	public function appartient_int( int $x0 ) : bool
	{
		return in_array( $x0, $this->tab );
	}


	// On suppose que XX est un array de TabInt
	// Retourne si l'objet courant appartient à XX
	//
	public function appartient_ens( array $XX ) : bool
	{
		foreach( $XX as $X )
		{
			if( TabInt::ensemblesEgaux($this,$X) ) return true ;
		}
		return false ;
	}



	// Retourne si l'objet courant est un sous ensemble de X0
	//
	public function estUnSousEnsemble( TabInt $X0 ) : bool
	{
		foreach( $this->tab as $x )
		{
			if( ! $X0->appartient_int($x) ) return false ;
		}
		return true ;
	}


	//  ---------------------------------- AUTRES MÉTHODES ----------------------------------


	// On suppose que XX est un tableau de TabInt 
	// Retourne les entiers présents dans $XX
	//
	public static function entiersPresents( array $XX ) : array
	{
		$res = array();
	
		foreach( $XX as $tabInt )
		{
			foreach( $tabInt->tab as $x )
			{
				if( !in_array($x,$res) ) array_push( $res, $x );
			}
		}
	
		return $res ;
	}
	

	// Retourne le nombre d'élément en commun entre X1 et X2
	//
	public static function nbElementEnCommun( TabInt $tabInt1, TabInt $tabInt2 ) : int
	{
		$res = 0 ;

		foreach( $tabInt1->tab as $x1 )
		{
			foreach( $tabInt2->tab as $x2 )
			{
				if( $x1 == $x2 ) {
					$res++ ;
					break ;
				}
			}
		}

		return $res ;
	}
	
	
	public static function arrayTabInt_to_arrayArray( $arrayTabInt )
	{
		$res = array();

		foreach( $arrayTabInt as $tabInt )
		{
			array_push( $res, $tabInt->tab );
		}

		return $res ;
	}
}
	class Sr extends BaseController
	{
		public function __construct()
        {
            $this->modele = new modele();
		}
		/*================================================================================================================
									||
			LISTE DES PARTIES		||
									||
		==============================

			+ FONCTION PRINCIPALE

			+ GENERER UN SR POUR k=1

			+ GENERER UN SR POUR k DANS {2,3,4}

			+ GENERER COMBINAISONS

			+ CLASSE TabInt



		/*================================================================================================================
									||
			FONCTION PRINCIPALE		||
									||
		============================*/

		// Retour:
		//		+ retourne un SR de paramètre (A,k)
		//      + type: array de TabInt
		//
		function genererSR( /*array $A, int $k*/ ) 
		{
			$A = array();
			$temp = $this->request->getPost('boule');
			foreach ($temp as $data => $value) {
				array_push($A,(int)$value);
			}
			$k = (int)$this->request->getPost('obj');

			
			if( $k == 1 ) $aux = $this->genererSR_1( $A );
			if( $k == 5 ) $aux = $this->combinaisons( $A, $k );
			else $aux = $this->genererSR_234( $A, $k );
			$data = array();
			$data['data'] = TabInt::arrayTabInt_to_arrayArray($aux);
			
			return view("grille",$data);
		}



		/*================================================================================================================
										||
			GENERER UN SR POUR k=1		||
										||
		================================*/

		// Retour:
		//		+ retourne SR pour k=1
		//      + type: array de TabInt
		//
		function genererSR_1( array $A ) : array
		{
			$res = array();

			$grille = array(); 
			$i = 0 ;
			foreach( $A as $num )
			{
				$i++ ;
				array_push( $grille, $num );
				if( $i == 5 ) 
				{
					array_push( $res, new TabInt($grille) );
					$grille = array(); 
					$i = 0 ;
				}
			}
			
			if( $i != 0 )
			{
				$j = 0 ;
				while( $i < 5 )
				{
					array_push( $grille, $A[$j] );
					$j++ ;
					$i++ ;
				}
				array_push( $res, new TabInt($grille) );
			}

			return $res ;
		}



		/*================================================================================================================
													||
			GENERER UN SR POUR k DANS {2,3,4}		||
													||
		============================================*/

		// Paramètre:
		//		+ resAcc est un accumulateur
		//
		// Retour:
		//		+ renvoie un SR pour k élément de {2,3,4}
		//      + type: array de TabInt
		//
		function genererSR_234( array $A, int $k, array $resAcc = array() ) : array
		{
			$aux = $this->combinaisons( $A, 5, true );
			$res = array_merge( $resAcc, $aux );
			$CombisNonIncluses = $this->kCombi_non_incluses( $A, $k, $res );

			if( count($CombisNonIncluses) == 0 ) return $res ;
			
			$A2 = TabInt::entiersPresents( $CombisNonIncluses );
			if( count($A2) <= 5 )
			{
				$A2 = $this->completerEn5combinaison( $A2, $A );
				array_push( $res, new TabInt($A2) );
				return $res ;
			}
			
			return $this->genererSR_234( $A2, $k, $res );
		}



		// Paramètres:
		//		+ A0: ensemble de numéro
		//		+ ensDe5Combi: ensemble de 5-combinaisons
		//
		// Retour:
		//		+ Renvoie toutes les k-combinaisons de $A0 qui ne sont pas inclus dans au moins l'un des éléments de $ensDe5Combi
		//      + type: array de TabInt
		//
		function kCombi_non_incluses( array $A0, int $k, array $ensDe5Combi ) : array
		{
			$res = array();
			$ttLeskCombi = $this->combinaisons( $A0, $k );

			foreach( $ttLeskCombi as $kCombi )
			{
				$trouve = false ;

				foreach( $ensDe5Combi as $_5Combi )
				{
					if( $kCombi->estUnSousEnsemble($_5Combi) ) {
						$trouve = true ;
						break ;
					}
				}

				if( !$trouve ) array_push( $res, $kCombi );
			}

			return $res ;
		}



		// Paramètres:
		//		+ A2: un ensemble de numéro
		//      + A0: ensemble de numéros
		//
		// Retour:
		//		+ renvoie A2 complété avec des éléments de A0 en 5-combinaison
		//      + type: array de int
		//
		function completerEn5combinaison( array $A2, array $A0 ) : array
		{
			$n2 = count($A2);

			$i = 0 ;
			while( $n2 < 5 )
			{
				if( !in_array($A0[$i], $A2) ) 
				{
					array_push( $A2, $A0[$i] );
					$n2++ ;
				}
				$i++ ;
			}

			return $A2 ;
		}



		/*================================================================================================================
									||
			GENERER COMBINAISONS	||
									||
		============================*/

		// Paramètres:
		// 		+ E: un ensemble d'entier
		// 		+ k: entier inférieur ègal à card(E)
		//		+ unSeulEnCommun0
		//
		// Retour:
		//		+ si( unSeulEnCommun == false ) : retourne un tableau contenant toutes les k-combinaisons de E
		//		+ sinon: retourne un tableau contenant des k-combinaisons de E qui n'ont qu'un seul élément en commun
		//
		function combinaisons( array $E, int $k, bool $unSeulEnCommun0 = false ) : array
		{
			$res = array();
			$evolutions = array();
			$kUplet = new TabInt();
			$n = count($E);																

			
			for( $i=0 ; $i<$k ; $i++ )															// initialisation
			{
				array_push( $evolutions, 0 );													// evolutions[i] contiendra l'indice 'ind' tq:  E[ind] == kUplet[i]
				$kUplet->push( $E[0] );
			}

			$r = $k-1 ;																			// nb de coordonnee qui n'ont pas tournés ( on considère que la dernière coordonnée à tourner pour arriver à la valeur initiale )
			while( $r >= 0 )
			{		
				if( $this->filtrageCombinaison($kUplet,$res,$unSeulEnCommun0) ) {
					array_push( $res, $kUplet->copie() );										// on sauvegarde la combinaison
				}

				$aFiniDeTourner = true ;
				$i = $k-1 ;
				while( $aFiniDeTourner && ($i>=$r) )
				{
					if( $evolutions[$i] != $n-1 ) $aFiniDeTourner = false ;						// si un element n'a pas fini de tourné
					else $i-- ;
				}

				if( $i != -1 )																	// ( pour r=0, on pourra avoir i=-1 )
				{
					$evolutions[$i] += 1 ;														// on le fait tourné
					$kUplet->set( $i, $E[$evolutions[$i]] );
					for( $j=$k-1 ; $j>$i ; $j-- )
					{										
						$evolutions[$j] = 0 ;													// on fait revenir les autres à 0
						$kUplet->set( $j, $E[0] );
					}			
				}

				if( $aFiniDeTourner ) $r-- ;
			}


			return $res ;
		}



		// Paramètres:
		// 		+ kUplet: k-uplet 
		//		+ XX: ensemble de kUplet ( array de TabInt )
		//		+ unSeulEnCommun0
		//
		// Retour:
		//		+ si( unSeulEnCommun0 == false ) : retourne si kUplet est une combinaison ET si il n'appartient pas à XX
		//		+ sinon : retourne si $kUplet est une combinaison ET s'il n'a qu'un seul entier en commun avec chaque k-uplet de XX
		//
		function filtrageCombinaison( TabInt $kUplet, array $XX, bool $unSeulEnCommun0 ) : bool
		{
			if( $kUplet->estUnEnsemble() )
			{		
				if( $unSeulEnCommun0 == false )
				{	
					if( ! $kUplet->appartient_ens($XX) ) return true ;
				}	
				else
				{
					foreach( $XX as $X )
					{
						$nb = TabInt::nbElementEnCommun( $kUplet, $X );
						if( $nb > 1 ) return false ;
					}
					return true ;
				}
			}
			return false ;
		}

	}


/*================================================================================================================
						||
	CLASSE TabInt		||
						||
========================*/


	









