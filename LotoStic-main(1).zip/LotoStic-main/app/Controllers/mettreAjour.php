<?php namespace App\Controllers;

use App\Models\Modele;

	class Mettreajour extends BaseController
	{
		public function __construct()
        {
            $this->modele = new modele();
		}
		
		public function index()
		{
			return view('update');
		}
	/*=============================================================================================================================================
								||
		LISTE DES FONCTIONS		||
						||
	============================||


	FONCTION PRINCIPALE:
		+ mettreAJourLesDonnees()


	FONCTIONS POUR RECUPERER FICHIER CSV DEPUIS LE SITE DE LA FDJ:
		+ recupererTousLesLiensDeResultat()
		+ recupererFichierCSV( string $lien, string $nomCSV )


	FONCTIONS POUR LIRE FICHIER CSV:
		+ lireFichierCSV( string $nomFichier )
		+ lireEnTete( $fichier )
		+ lireUneLigne( $fichier )
		+ lireUneCellule( $fichier )


	/*=============================================================================================================================================
								||
		FONCTION PRINCIPALE		||
								||
	============================*/


	// Insere les nouveaux tirages dans la BDD
	//
	public function mettreAJourLesDonnees()
	{
		$nom = "resLoto.csv" ;
		$tousLesLiens = $this->recupererTousLesLiensDeResultat();

		foreach( $tousLesLiens as $lien )
		{	
			if( $this->recupererFichierCSV($lien,$nom) ) 
			{
				$ret = $this->lireFichierCSV( $nom );
				if( $ret == 2 ) break ;									// si un tirage a déjà été injecté
			}
		}

		unlink( $nom );
		//return view('update');
		echo "Mise à jour terminée";
	}



	/*=============================================================================================================================================
																			||
		FONCTIONS POUR RECUPERER FICHIER CSV DEPUIS LE SITE DE LA FDJ		||
																			||
	========================================================================*/


	// Retourne un tableau contenant tous les liens de resultat du loto
	//
	function recupererTousLesLiensDeResultat() : array
	{
		$res = array();	
		$url = "https://www.fdj.fr/jeux-de-tirage/loto/resultats" ;
		$exprReg = "#(https?://[a-z0-9-_./?&%:;=]+)#i" ;
		$prefixe = "https://media.fdj.fr/static/csv/loto/loto_2" ;

		$contenuFichier = file_get_contents( $url );	
		$decoupage = preg_split( $exprReg, $contenuFichier, null, PREG_SPLIT_DELIM_CAPTURE );

		foreach( $decoupage as $lien )
		{
			if( strstr($lien,$prefixe) )												// si c'est un lien de résultat
			{
				if( !in_array($lien,$res) ) array_push( $res, $lien );
			}
		}

		return $res ;
	}



	// Effet:
	//		1. Recupère un '.zip' depuis $url
	//		2. Dezippe le '.zip' pour obtenir un '.csv'
	//		3. Supprime le '.zip'
	//		4. Renomme le '.csv' en $nomCSV
	//
	// Retour:
	//		+ retourne si tout à fonctionner
	//
	function recupererFichierCSV( string $lien, string $nomCSV ) : bool
	{
		// On récupère le contenu du fichier à l'url précicé
		file_put_contents("Tmpfile.zip", fopen($lien, 'r'));
		/*$contenuFichierTelecharge = file_get_contents( $lien );
		if( $contenuFichierTelecharge == false ) {
			echo "<br> erreur: file_get_contents <br>" ;
			return false ;
		}

		// On met le contenu du fichier telechargé dans un fichier zip 
		$ret = file_put_contents( "resultatLoto.zip", $contenuFichierTelecharge );
		if( $ret == false ) {
			echo "<br> erreur: file_put_contents <br>" ;
			return false ;
		}
		
		// On dézippe et on supprime le '.zip'
		exec( "unzip Tmpfile.zip" );
		//unlink( "resultatLoto.zip" );*/
		$this->unzip("Tmpfile.zip");
		unlink( "Tmpfile.zip" );
		
		// On recherche le fichier dézippé
		$listeFichier = scandir( "." );
		foreach( $listeFichier as $fichierDezippe )
		{
			if( strstr($fichierDezippe, ".csv") ) break ;		
		}
		
		// On renomme le fichier
		$ret = rename( $fichierDezippe, $nomCSV );
		if( $ret == false ) {
			echo "<br> erreur: rename <br>" ;
			return false ;
		}

		// On donne les droits sur ce fichier
		
		$ret = chmod( $nomCSV, 0777 );

		if( $ret == false ) {
			echo "<br> erreur: chmod <br>" ;
			return false ;
		}

		return true ;
	}



	/*=============================================================================================================================================
											||
		FONCTIONS POUR LIRE FICHIER CSV		||
											||
	========================================*/


	// Effet:
	//		+ Insère dans la BDD les tirages de $nomFichier qui n'ont jamais été insérés
	//
	// Retour:
	//		-1: si erreur
	//		1:  si fin du fichier
	//		2:  si un tirage était dans la BDD
	//
	function lireFichierCSV( string $nomFichier ) : int
	{
		//$this->load->model('modele'); //Load the Model here
		// Ouverture fichier
		
		$fichier = fopen( $nomFichier, "r" );	

		if( $fichier == false )
		{
			echo "<br> erreur d'ouverture fichier CSV <br>" ;
			return -1 ;	
		}

		// Analyse de l'en-tête
		$ret = $this->lireEnTete( $fichier );										
		if( $ret == false ) 
		{
			echo "<br> erreur: en tête incorrecte <br>" ;
			fClose( $fichier );
			return -1 ;
		}
		
		
		// Parcours du fichier
		$idMax = $this->modele->getIdMax();
		
		do{																	
			$res = 0 ;
			$tirage = $this->lireUneLigne( $fichier );
			
			if( $tirage == false ) $res = 1 ; 									// si on est à la fin du fichier
			elseif( $tirage[0] <= $idMax ) $res = 2 ;							// si le tirage à déjà été injecté
			else $this->modele->injecterUnTirage( $tirage );
		}while( $res == 0 );
		
		// fermeture fichier
		fClose( $fichier );
		return $res ;
	}



	// Retourne si l'en-tête est correcte
	//
	function lireEnTete( $fichier ) : bool
	{
		$vraisAttributs = [ "annee_numero_de_tirage", "jour_de_tirage", "date_de_tirage", "date_de_forclusion", "boule_1", "boule_2", "boule_3", "boule_4", "boule_5", "numero_chance" ] ;
		
		foreach( $vraisAttributs as $vrai )										// on verifie les premières en-tête
		{
			$attr = $this->lireUneCellule( $fichier );
			if($attr != $vrai) return false ;
		}

		while( $this->lireUneCellule($fichier) != "devise"  );							// finir cette ligne

		return true ; 
	}



	// Si fin du fichier: retourne false
	// Sinon: retourne le tableau contenant l'id et les numéros du tirage
	//
	function lireUneLigne( $fichier )
	{
		$aux = $this->lireUneCellule( $fichier );
		if( $aux == false ) return false ;										// si on est à la fin du fichier

		$res = array();
		array_push( $res, intval($aux) );										// clé
		$this->lireUneCellule( $fichier );												// jour de tirage
		$this->lireUneCellule( $fichier );												// date de tirage
		$this->lireUneCellule( $fichier );												// date de forclusion
		for( $i=1 ; $i<=6 ; $i++ ) {
			array_push( $res, $this->lireUneCellule($fichier) );						// boule i
		}

		while( $this->lireUneCellule( $fichier ) != "eur" );							// finir cette ligne
		$c = fgetc( $fichier );

		return $res ;
	}



	// Si fin du fichier: retourne false
	// Sinon: retourne le contenu de la prochaine cellule
	//
	function lireUneCellule( $fichier )
	{
		$res = "" ;
			
		$c = fgetc( $fichier );
		while( (!feof($fichier)) && ($c != ";") )
		{
			$res = $res . $c ;
			$c = fgetc( $fichier );
		}

		if( feof($fichier) ) return false ;
		
		return $res ;
	}

	//UNZIP FILE
	
function unzip($file){

    $zip=zip_open(realpath(".")."/".$file);
    if(!$zip) {return("Unable to proccess file '{$file}'");}

    $e='';

    while($zip_entry=zip_read($zip)) {
       $zdir=dirname(zip_entry_name($zip_entry));
       $zname=zip_entry_name($zip_entry);

       if(!zip_entry_open($zip,$zip_entry,"r")) {$e.="Unable to proccess file '{$zname}'";continue;}
       if(!is_dir($zdir)) $this->mkdirr($zdir,0777);

       #print "{$zdir} | {$zname} \n";

       $zip_fs=zip_entry_filesize($zip_entry);
       if(empty($zip_fs)) continue;

       $zz=zip_entry_read($zip_entry,$zip_fs);

       $z=fopen($zname,"w");
       fwrite($z,$zz);
       fclose($z);
       zip_entry_close($zip_entry);

    }
    zip_close($zip);

    return($e);
}

function mkdirr($pn,$mode=null) {

  if(is_dir($pn)||empty($pn)) return true;
  $pn=str_replace(array('/', ''),DIRECTORY_SEPARATOR,$pn);

  if(is_file($pn)) {trigger_error('mkdirr() File exists', E_USER_WARNING);return false;}

  $next_pathname=substr($pn,0,strrpos($pn,DIRECTORY_SEPARATOR));
  if($this->mkdirr($next_pathname,$mode)) {if(!file_exists($pn)) {return $this->mkdir($pn,$mode);} }
  return false;
}



	}
?>