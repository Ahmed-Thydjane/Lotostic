$(document).ready(function () {
    
    document.getElementById("maj").onclick = function () {
        location.href = "/maj";
    };
    document.getElementById("stats").onclick = function () {
        location.href = "/stats";
    };
    document.getElementById("grille").onclick = function () {
        location.href = "/grille";
    };
});