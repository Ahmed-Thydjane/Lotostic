$(document).ready(function () {
    
  $.get(
    '/plustire',  
    bartChartGraphPlus,          
    'json'                    
  );
  
  $.get(
    '/moinstire',  
    bartChartGraphMoins,          
    'json'                    
  );
  

});

function bartChartGraphPlus(data){
  
  var t_key = Object.keys(data);
  var t_value = [];
  for (var key in data) {
    if (data.hasOwnProperty(key)) {
        t_value.push(data[key]);
    }
  }

  var ctx = document.getElementById("myBarChart");
  var graph = new Chart(ctx,{
    type: 'bar',
    data: {
      labels: t_key,
      datasets: [
        {
          label: "Frequence (en nombre de fois)",
          backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f","#e8c3b9","#c45850"],
          data: t_value
        }
      ]
    },
    options: {
      legend: { display: false },
      title: {
        display: true,
        text: 'Frequence (en nombre de fois)'
      },
      maintainAspectRatio: false,
      layout: {
        padding: {
          left: 10,
          right: 25,
          top: 25,
          bottom: 0
        }
      }
    }
});

}

function bartChartGraphMoins(data){

  var t_key = Object.keys(data);
  var t_value = [];
  for (var key in data) {
    if (data.hasOwnProperty(key)) {
        t_value.push(data[key]);
    }
  }

  var ctx = document.getElementById("myBarChart2");
  var graph = new Chart(ctx,{
    type: 'bar',
    data: {
      labels: t_key,
      datasets: [
        {
          label: "Frequence (en nombre de fois)",
          backgroundColor: ["#bdbdbd", "#8d8d8d","#cfcfcf","#9e9e9e","#707070"],
          data: t_value
        }
      ]
    },
    options: {
      legend: { display: false },
      title: {
        display: true,
        text: 'Frequence (en nombre de fois)'
      },
      maintainAspectRatio: false,
      layout: {
        padding: {
          left: 10,
          right: 25,
          top: 25,
          bottom: 0
        }
      }
    }
});

}

