<?php


$bdd = connexion_PDO();
$idMax = maxId( $bdd );


function connexion_PDO()
{
    $dsn = "mysql:host=localhost;dbname=lotostic" ;
    $login = "root" ;
    $mdp = "root" ;
    $options =
    [
        PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, 
    ];

    try {
        $connexion = new PDO( $dsn, $login, $mdp, $options ) ;
        echo "<br> >>>>>>>>>>>>>connexion BDD>>>>>>>>>>>>>> <br>" ;
        return $connexion ;
        
    } catch( PDOException $e ) 
    {
        print "Erreur de connexion PDO" ;
        die() ;
    }
}



function maxId( $bdd )
{
    echo "<br> -------------maxId------------------ <br>" ;
    
    $req = $bdd->query( "SELECT COUNT(*) FROM tirages" );
    $tab = $req->fetch();
	
	if( $tab[0] == 0 ) return 0 ;
	else
	{
		$req = $bdd->query( "SELECT MAX(id) FROM tirages" );
		$tab = $req->fetch();
		return $tab[0] ;  
	}
}



// Injecte le tirage dans la BDD
//
function injecterUnTirage( array $tirage )
{
    global $bdd ;
	$req = $bdd->prepare( "INSERT INTO tirages(anne_numero,boule1,boule2,boule3,boule4,boule5,num_chance) VALUES (:an,:b1,:b2,:b3,:b4,:b5,:bC)" );  
	$res = $req->execute( [
				'an' => $tirage[0],
				'b1' => $tirage[1],
				'b2' => $tirage[2],
				'b3' => $tirage[3],
				'b4' => $tirage[4],
				'b5' => $tirage[5],
				'bC' => $tirage[6],
	] );
}



function tousLesTirages()
{
    global $bdd ;
    return $bdd->query( "SELECT boule1,boule2,boule3,boule4,boule5,num_chance FROM tirages" );
}


?>